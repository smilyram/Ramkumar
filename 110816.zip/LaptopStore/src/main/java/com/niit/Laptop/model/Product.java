package com.niit.Laptop.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;



@Entity
public class Product {

@Id@GeneratedValue(strategy=GenerationType.AUTO)
@NotEmpty(message="should not be empty")
@Size(min=3, message="must have atleast three digits")
private int pid;

@NotEmpty(message="pname should not empty")
private String pname;
@Size(min=20, message="must have atleast 20 characters")
private String pdesc;
@NotEmpty(message="price should not empty")
private double price;
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public String getPdesc() {
	return pdesc;
}
public void setPdesc(String pdesc) {
	this.pdesc = pdesc;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}





}
