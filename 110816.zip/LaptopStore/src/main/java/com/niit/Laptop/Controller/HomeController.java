package com.niit.Laptop.Controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.niit.Laptop.model.Product;


@Controller
public class HomeController
{
	
ModelAndView mv;

@RequestMapping(value="/")
public ModelAndView  HomePage()
{
	mv = new ModelAndView("home");
	
	return mv;
	
}


String setName;
@RequestMapping("/LProduct")
public ModelAndView Allproductdetails(
	@RequestParam(value = "name", required = false, defaultValue = "bag") String name) {
		System.out.println("request maped with productdetails page()");
		ModelAndView allprod = new ModelAndView("ProductDetails");
		setName = name;
		System.out.println(setName);
		return allprod;
}
@Autowired
ProductServiceImpl prservice;


List<Product> plist;
@SuppressWarnings("unchecked")
@RequestMapping("/GsonCon")
public @ResponseBody String getValues()throws Exception
{
	String result = "";
	
	if(setName.equals("all")){			
		plist = prservice.getProducts();
		Gson gson = new Gson();			  
		result = gson.toJson(plist);			
	}
	else{
		System.out.println("Controller : "+setName);
		Product pm = prservice.getProduct(Integer.parseInt(setName));
		List<Product> list = new ArrayList<Product>();
		list.add(pm);
		Gson gson = new Gson();
		result = gson.toJson(list);
	}
	return result;
}



}
