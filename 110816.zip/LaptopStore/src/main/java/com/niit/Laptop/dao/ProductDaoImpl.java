package com.niit.Laptop.dao;

import org.hibernate.Query;
import com.niit.Laptop.model.*;

import java.util.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;


public class ProductDaoImpl implements ProductDao
{

	List<Product> products;
	
	public ProductDaoImpl() 
	{	}
	
	@Autowired
	private SessionFactory sessionFactory;

	private Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	public void addProduct(Product pm) 
	{
		Session s=sessionFactory.getCurrentSession();
		s.saveOrUpdate(pm);
	}

	public void updateProduct(Product pm) {
		Session sessionUpd = sessionFactory.openSession();
	    Transaction tx = (Transaction) sessionUpd.beginTransaction();
	    sessionUpd.saveOrUpdate(pm);
	    tx.commit();	    
	    sessionUpd.close();		
	}

	public void deleteProduct(int id) {
		Session sessionDel = sessionFactory.openSession();
		Transaction tx = sessionDel.beginTransaction();
		Product pm = (Product) sessionDel.load(Product.class, id);
		sessionDel.delete(pm);
	    tx.commit();
	    sessionDel.close();
	}

	public Product getProduct(int id) {
		System.out.println("DAO Implementation : "+id);
		Session ss = sessionFactory.getCurrentSession(); 
		Product pm = (Product) ss.get(Product.class, id);
		//ss.flush();
		return pm;
	}
	
	public Product getRowById(int id) {
		Session ses = sessionFactory.openSession();
		Product pm = (Product) ses.load(Product.class, id);
	    return pm;
	} 
	
	@SuppressWarnings("unchecked")
	public List<Product> getAllProducts()
	{
		System.out.println("DAO Implementation");
		Session ss1 = sessionFactory.openSession();
		Query qry = ss1.createQuery("from Product");
		System.out.println(qry.toString());
		products = (List<Product>)qry.list();
		return products;
	}
}