

package com.niit.Laptop.dao;

import com.niit.Laptop.model.*;
import java.util.List;

public interface ProductDao 
{
	public void addProduct(Product pm);
	public void updateProduct(Product pm);
	public void deleteProduct(int id);
	public Product getProduct(int id);
	public List<Product> getAllProducts();
	public Product getRowById(int id);
	


}
