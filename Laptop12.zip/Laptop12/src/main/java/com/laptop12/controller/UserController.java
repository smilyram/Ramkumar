package com.laptop12.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.laptop12.model.Item;
import com.laptop12.service.CategoryService;

 @Controller
public class UserController {
	@Autowired
	CategoryService categoryService;
	
	@RequestMapping("/i3")//this for edit code in view products
	public ModelAndView editItem(@RequestParam("category") String category)
	{
		System.out.println("category"+category);
		Item item=categoryService.getItemByCategory(category);
		System.out.println("Item name"+item.getItemName());
	return new ModelAndView("i3","item",item);
	}
}
