package com.niit.laptopbackend123.dao;

import java.util.List;

import com.niit.laptopbackend123.model.Category;

public interface CategoryDAO {



	public List<Category> myList();

	public Category getRow(String id);
	
	public void saveOrUpdateRow(Category category);

	public void deleteRow(String id);



}