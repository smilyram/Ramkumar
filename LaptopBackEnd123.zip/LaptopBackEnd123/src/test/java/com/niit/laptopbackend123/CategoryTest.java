package com.niit.laptopbackend123;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.laptopbackend123.dao.CategoryDAO;
import com.niit.laptopbackend123.model.Category;

public class CategoryTest {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.laptopbackend123");
		context.refresh();

		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");

		Category category = (Category) context.getBean("category");
		category.setId("i am a ");
		category.setName("bad");
		category.setDescription("boy");

		categoryDAO.saveOrUpdateRow(category);

	}

}

