package com.niit.ShoppingCart123;

public class LoginDAO {
	private Object ramu;

	public boolean isValidUser(String uname,String pwd){
		if(uname.equals(ramu)&&pwd.equals(1234)){
			return true;
		}
		else
			return false;
	}

}
