package com.laptop12.service;

import com.laptop12.model.Customer;

public interface CustomerService {
	void addCustomer(Customer customer);

}
