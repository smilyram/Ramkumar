package com.laptop12.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.laptop12.model.Customer;
@Repository
public class CustomerDaoImpl implements CustomerDao {
	
	//it will create session the object which was created in appl-contx
	@Autowired
	SessionFactory sessionFactory;
	//saving the Scustomer
	public void addCustomer(Customer customer) 
	{
		System.out.println("im in add customer repository");
		Session session=sessionFactory.getCurrentSession();
		Transaction trasaction=session.beginTransaction();
		session.save(customer);
		trasaction.commit();
		System.out.println("Done the saving cusomer");
		
	}
	
	
}
