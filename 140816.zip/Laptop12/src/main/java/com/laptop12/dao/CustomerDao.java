package com.laptop12.dao;

import com.laptop12.model.Customer;

public interface CustomerDao {
	void addCustomer(Customer customer);

}
