package com.laptop12.controller;

import java.io.IOException;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.laptop12.model.Customer;
import com.laptop12.model.Item;
import com.laptop12.service.CustomerService;

@Controller
public class AdminController {
	@Autowired
	CustomerService customerService;
	@RequestMapping("/ViewCustomer")
	public ModelAndView viewCustomer() throws JsonGenerationException, JsonMappingException, IOException
	{
		List<Customer> list=customerService.viewCustomer();
		System.out.println("List is:"+list);
		ObjectMapper mapper=new ObjectMapper();
		String listJSON=mapper.writeValueAsString(list);
		System.out.println(listJSON);
		return new ModelAndView("ViewCustomer","listOfCustomer",listJSON);
	}
	@RequestMapping("/addItem")
	public ModelAndView addItem()
	{
		Item item=new Item();
		return new ModelAndView("addItem","item",item);
	}

}
