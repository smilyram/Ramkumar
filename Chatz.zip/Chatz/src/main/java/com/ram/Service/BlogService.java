package com.ram.Service;

import java.util.List;

import com.ram.model.Blog;

public interface BlogService {
	public void createNewBlog(Blog blog);
	public List<Blog> getBlogList(String bUserName);
	public Blog getBlogById(int bid);
	public Blog getBlogByName(String bUsername);
	public List<Blog> getBlog();
}
