package com.ram.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ram.Service.ForumService;
import com.ram.model.Forum;
@Controller
public class ForumController {
	@Autowired
	private ForumService fservice;

	@RequestMapping("/newforum")
	public String createBlog(HttpServletRequest request,Model model)
	{
		String name=request.getParameter("forum");
		model.addAttribute("name",name);
		System.out.println("In Forum Controller");
		return "forum";
	}
	@ModelAttribute("/forum")
	public Forum returnObject()
	{
		System.out.println("forum page");
		return new Forum();
	}

	@RequestMapping("/postF")
	public String postblog(@Valid@ModelAttribute("forum") Forum forum , Model model) throws IOException
	{
		System.out.println("I am in Forum");
		
		forum.setForumUserName("Ram inviting yoU");
		/*forum.setCreationDate(new java.util.Date());*/
		
		fservice.createNewForum(forum);
		
		return "forum";
	
	}
	
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/GsonCon1")
	public @ResponseBody String getValues() throws Exception
	{
		List<Forum> flist;
		String result="";
		flist = fservice.getForum();
		Gson gson = new Gson();
		result = gson.toJson(flist);
		System.out.println("before flist");
		System.out.println(flist);
		return result;
	}


}
