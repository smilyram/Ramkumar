package com.ram.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ram.Service.BlogService;
import com.ram.model.Blog;


@Controller
public class BlogController 
{
	@Autowired
	BlogService blogService;


	@RequestMapping("/blog")
	public String createBlog(HttpServletRequest request,Model model)
	{
		String name=request.getParameter("blog");
		model.addAttribute("name",name);
		System.out.println("In Blog Controller");
		return "blogPage";
	}
	@ModelAttribute("blog")
	public Blog returnObject()
	{
		return new Blog();
	}

	@RequestMapping("/postb")
	public String postblog(@ModelAttribute("blog") Blog blog , Model model) throws IOException
	{
		System.out.println("I am in blogpost");
		blog.setbUsername("Ram");
		blog.setCreationdatetime(new java.util.Date());
		blogService.createNewBlog(blog);
		
		return "blogPage";
	}
	String setName;

	List<Blog> blist;
	@SuppressWarnings("unchecked")
	@RequestMapping("/GsonCon")
	public @ResponseBody String getValues()throws Exception
	{
		String result = "";
		
			
			blist = blogService.getBlog();
			Gson gson = new Gson();			  
			result = gson.toJson(blist);			
		
		
		return result;
	}


}
