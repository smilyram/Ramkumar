package com.ram.Dao;

import java.util.List;

import com.ram.model.Forum;

public interface ForumDAO {
	public void createNewForum(Forum forum);
	public List<Forum> getForumList(String forumUserName);
	public void delete(int forumId);
	public List<Forum> getForum();
}
