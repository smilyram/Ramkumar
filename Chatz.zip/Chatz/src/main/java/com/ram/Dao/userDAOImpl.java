package com.ram.Dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ram.model.User;


@Repository
public class userDAOImpl implements UserDAO{
	@Autowired
	SessionFactory sessionFactory;

	
	public void saveOrUpdate(User user) {
		Session s =sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		s.saveOrUpdate(user);
		t.commit();

	}

	
	public User getUserById(int userId) {
		Session session=sessionFactory.getCurrentSession();
		Transaction tx=session.beginTransaction();
		User user=(User) session.load(User.class,userId);
		System.out.println("data of user by id="+user);
		tx.commit();
		return user;
	}

	
	public List<User> list() {
		@SuppressWarnings("unchecked")
		Session session=sessionFactory.getCurrentSession();
		@SuppressWarnings("unchecked")
		List<User> user = (List<User>)
				sessionFactory.getCurrentSession().createCriteria(User.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return user;
	}

	
	public User getUserByName(String userName) {
		System.out.println("getting data in dao based on name"+userName);
		Session session=this.sessionFactory.getCurrentSession();
		Transaction tx=session.beginTransaction();
		Criteria cr=session.createCriteria(User.class);
		cr.add(Restrictions.eq("username", userName));
		List<User> users = cr.list();
		User user = users.get(0);
		System.out.println("User Data="+user.getUserName());
		tx.commit();
		return user;

	}

}
