package com.ram.Dao;

import java.util.List;

import com.ram.model.Blog;

public interface BlogDAO {
	public void createNewBlog(Blog blog);
	public List<Blog> getBlogList(String bUsername);
	public Blog getBlogById(int bid);
	public Blog getBlogByName(String bUsername);
	public void delete(int bid);
	public List<Blog> getBlog();
}
