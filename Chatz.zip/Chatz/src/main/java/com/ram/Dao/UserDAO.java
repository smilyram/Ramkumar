package com.ram.Dao;

import java.util.List;

import com.ram.model.User;

public interface UserDAO {
	public void saveOrUpdate(User user);
	public User getUserById(int userId);
	public List<User> list();
	public User getUserByName(String userName);
}
