package com.ram.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Blog {
	@Id@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private int bid;
	@NotEmpty(message="should not empty")
	private String btitle;
	@NotEmpty(message="should not empty")
	private String bcontent;
	@NotEmpty(message="should not empty")
	private String bUsername;
	private Date creationdatetime;
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBtitle() {
		return btitle;
	}
	public void setBtitle(String btitle) {
		this.btitle = btitle;
	}
	public String getBcontent() {
		return bcontent;
	}
	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}
	public String getbUsername() {
		return bUsername;
	}
	public void setbUsername(String bUsername) {
		this.bUsername = bUsername;
	}
	public Date getCreationdatetime() {
		return creationdatetime;
	}
	public void setCreationdatetime(Date creationdatetime) {
		this.creationdatetime = creationdatetime;
	}
	
}
